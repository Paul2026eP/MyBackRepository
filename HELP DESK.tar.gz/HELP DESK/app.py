from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Configuração da conexão com o banco de dados
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",          # Altere para seu usuário do MySQL
        password="escola",    # Altere para sua senha do MySQL
        database="helpdesk_db"
    )

@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Busca os técnicos para a lista de seleção
    cursor.execute("SELECT re, nome FROM tecnicos")
    tecnicos_lista = cursor.fetchall()
    
    # Busca dados para o Ranking de Técnicos
    cursor.execute("SELECT re, nome, chamados_atendidos FROM tecnicos ORDER BY chamados_atendidos DESC")
    ranking = cursor.fetchall()
    
    # CORREÇÃO AQUI: Trocado c.id por c.id_os
    cursor.execute("""
        SELECT c.id_os, c.equipamento, c.problema, c.nivel, t.nome as tecnico_nome 
        FROM chamados c 
        JOIN tecnicos t ON c.tecnico_re = t.re 
        WHERE c.status = 'Aberto'
    """)
    chamados_abertos = cursor.fetchall()
    
    cursor.close()
    conn.close()
    return render_template('index.html', tecnicos=tecnicos_lista, ranking=ranking, chamados=chamados_abertos)


@app.route('/finalizar_chamado/<int:chamado_id>', methods=['POST'])
def finalizar_chamado(chamado_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # CORREÇÃO AQUI: Trocado id por id_os na busca e no update
    cursor.execute("SELECT tecnico_re FROM chamados WHERE id_os = %s", (chamado_id,))
    chamado = cursor.fetchone()
    
    if chamado:
        tecnico_re = chamado['tecnico_re']
        
        cursor.execute("UPDATE chamados SET status = 'Finalizado' WHERE id_os = %s", (chamado_id,))
        cursor.execute("UPDATE tecnicos SET chamados_atendidos = chamados_atendidos + 1 WHERE re = %s", (tecnico_re,))
        conn.commit()
        
    cursor.close()
    conn.close()
    return redirect(url_for('index'))


@app.route('/criar_chamado', methods=['POST'])
def criar_chamado():
    equipamento = request.form['equipamento']
    problema = request.form['problema']
    nivel = request.form['nivel']
    tecnico_re = request.form['tecnico']
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Insere o novo chamado com status 'Aberto'
    cursor.execute(
        "INSERT INTO chamados (equipamento, problema, nivel, tecnico_re, status) VALUES (%s, %s, %s, %s, 'Aberto')",
        (equipamento, problema, nivel, tecnico_re)
    )
    
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
