DROP DATABASE IF EXISTS cantina;
CREATE DATABASE cantina;
USE cantina;

-- [FUNCIONALIDADE 1] Tabela para Cadastro e Login de Alunos
CREATE TABLE alunos (
    id_aluno INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    matricula VARCHAR(30) NOT NULL UNIQUE,
    senha VARCHAR(50) NOT NULL
);

-- Tabela base do Cardápio (Para servir de vínculo)
CREATE TABLE cardapio (
    id_cardapio INT AUTO_INCREMENT PRIMARY KEY,
    dia_semana VARCHAR(30) NOT NULL,
    refeicao_principal VARCHAR(255) NOT NULL
);

-- [FUNCIONALIDADE 2] Tabela de Agendamentos (Relaciona o Aluno ao Cardápio)
CREATE TABLE agendamentos (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno INT NOT NULL, 
    id_cardapio INT NOT NULL,
    data_reserva TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cardapio) REFERENCES cardapio(id_cardapio),
    FOREIGN KEY (id_aluno) REFERENCES alunos(id_aluno) ON DELETE CASCADE
);

-- [FUNCIONALIDADE 3] Tabela de Avisos Dinâmicos
CREATE TABLE avisos (
    id_aviso INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    conteudo TEXT NOT NULL
);

-- Inserindo dados iniciais corretos (Avisos Dinâmicos)
INSERT INTO avisos (titulo, conteudo) VALUES 
('Distribuição de Lanches', 'Amanhã a distribuição começará às 10h.'),
('Cardápio Especial', 'Preparamos um Dia da Saúde na Escola nesta semana!'),
('Lembrete', 'Atualize seu cadastro na secretaria caso mude de turma.');

-- Inserindo o cardápio base
INSERT INTO cardapio (dia_semana, refeicao_principal) VALUES 
('Segunda-feira', 'Arroz, Feijão, Frango Grelhado e Fruta de Sobremesa');

-- Usuário de teste padrão para sua apresentação (Matrícula: 123 / Senha: 123)
INSERT INTO alunos (nome, matricula, senha) VALUES ('Cleber Souza', '123', '123');
