from flask import Flask, render_template, redirect, url_for, request, session, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'chave_secreta_cantina' # Necessário para ativar o controle de login (sessions)

# Configurações do banco de dados 
bd_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'escola', 
    'database': 'cantina_digital_db'
}

@app.route('/')
def index():
    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor(dictionary=True)
        
        # [FUNCIONALIDADE 3] Busca os avisos dinamicamente no banco para a tela
        cursor.execute("SELECT titulo, conteudo FROM avisos")
        lista_avisos = cursor.fetchall()

        # Busca o cardápio do dia no banco
        cursor.execute("SELECT id_cardapio, refeicao_principal FROM cardapio WHERE dia_semana = 'Segunda-feira'")
        cardapio_hoje = cursor.fetchone()

        cursor.close()
        conectar.close()

        return render_template('index.html', avisos=lista_avisos, cardapio=cardapio_hoje)
    
    except mysql.connector.Error as err:
        return f"Erro ao carregar a página: {err}"

# [FUNCIONALIDADE 1] Rota para Processar o Cadastro de Alunos
@app.route('/cadastro', methods=['POST'])
def cadastro():
    nome = request.form['nome']
    matricula = request.form['matricula']
    senha = request.form['senha']
    
    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor()
        query = "INSERT INTO alunos (nome, matricula, senha) VALUES (%s, %s, %s)"
        cursor.execute(query, (nome, matricula, senha))
        conectar.commit()
        cursor.close()
        conectar.close()
        return redirect(url_for('cadastro.html'))
    except mysql.connector.Error as err:
        return f"Erro ao cadastrar aluno: {err}"

# [FUNCIONALIDADE 1] Rota para Processar o Login de Alunos
@app.route('/login', methods=['POST'])
def login():
    matricula = request.form['matricula']
    senha = request.form['senha']
    
    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor(dictionary=True)
        query = "SELECT id_aluno, nome FROM alunos WHERE matricula = %s AND senha = %s"
        cursor.execute(query, (matricula, senha))
        aluno = cursor.fetchone()
        cursor.close()
        conectar.close()
        
        if aluno:
            session['aluno_id'] = aluno['id_aluno']
            session['aluno_nome'] = aluno['nome']
        return redirect(url_for('index'))
    except mysql.connector.Error as err:
        return f"Erro ao fazer login: {err}"

# Rota para deslogar do sistema
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# [FUNCIONALIDADE 2] Rota para Processar o Agendamento de Refeição
@app.route('/agendar', methods=['POST'])
def agendar():
    if 'aluno_id' not in session:
        return redirect(url_for('index'))

    id_aluno = session['aluno_id']
    id_cardapio = request.form['id_cardapio']

    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor()
        query = "INSERT INTO agendamentos (id_aluno, id_cardapio) VALUES (%s, %s)"
        cursor.execute(query, (id_aluno, id_cardapio))
        conectar.commit()
        cursor.close()
        conectar.close()
        return redirect(url_for('index'))
    except mysql.connector.Error as err:
        return f"Erro ao gravar agendamento: {err}"

if __name__ == '__main__':
    app.run(debug=True)