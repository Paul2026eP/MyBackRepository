from flask import Flask, render_template, request
import mysql.connector
import re

app = Flask(__name__)

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "escola",
    "database": "calculadora_python",
}

def obter_conexao():
    return mysql.connector.connect(**DB_CONFIG)

def init_db():
    conn = obter_conexao()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS historico (
            id INT AUTO_INCREMENT PRIMARY KEY,
            conta TEXT NOT NULL,
            resultado DOUBLE NOT NULL
        )
    """)
    conn.commit()
    cursor.close()
    conn.close()

def obter_metricas():
    conn = obter_conexao()
    cursor = conn.cursor()

    # Correção dos índices [0] para evitar erros caso o banco retorne None
    cursor.execute("SELECT AVG(resultado) FROM historico")
    row_media = cursor.fetchone()
    media = row_media[0] if row_media and row_media[0] is not None else 0

    cursor.execute("SELECT MAX(resultado) FROM historico")
    row_maior = cursor.fetchone()
    maior = row_maior[0] if row_maior and row_maior[0] is not None else 0

    cursor.execute("SELECT COUNT(*) FROM historico")
    row_qtd = cursor.fetchone()
    quantidade = row_qtd[0] if row_qtd and row_qtd[0] is not None else 0

    cursor.close()
    conn.close()
    return {"media": round(media, 2), "maior": maior, "quantidade": quantidade}

def obter_grand_total():
    conn = obter_conexao()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(resultado) FROM historico")
    row_gt = cursor.fetchone()
    gt = row_gt[0] if row_gt and row_gt[0] is not None else 0
    cursor.close()
    conn.close()
    return gt

@app.route("/", methods=["GET", "POST"])
def calculadora():
    resultado = ""
    erro = None
    expressao_tela = ""

    if request.method == "POST":
        botao = request.form.get("botao")
        expressao_tela = request.form.get("expressao", "")

        try:
            # Tratamento do botão Grand Total (GT) da imagem
            if botao == "GT":
                resultado = str(obter_grand_total())
                expressao_tela = resultado
            
            # Tratamento do botão de calcular (=)
            elif botao == "=" and expressao_tela:
                # CORREÇÃO: Converte os símbolos visuais da tela para operadores válidos no Python
                expressao_limpa = expressao_tela.replace("×", "*").replace("÷", "/")
                
                # Sanitização para garantir que apenas caracteres matemáticos seguros sejam executados
                expressao_limpa = re.sub(r'[^\d+\-*/.]', '', expressao_limpa)
                
                # Tratamento especial para divisão por zero preventiva
                if "/0" in expressao_limpa:
                    raise ZeroDivisionError("Erro: Divisão por zero")

                # Avalia a expressão matemática de forma dinâmica
                res_calculado = eval(expressao_limpa)
                resultado = str(round(res_calculado, 4))
                
                # Salva no banco de dados MySQL
                conn = obter_conexao()
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO historico (conta, resultado) VALUES (%s, %s)",
                    (expressao_tela, float(resultado))
                )
                conn.commit()
                cursor.close()
                conn.close()
                
                expressao_tela = resultado  # Atualiza o visor com o resultado final

        except ZeroDivisionError as e:
            erro = str(e)
            expressao_tela = "Erro"
        except Exception:
            erro = "Erro de Sintaxe"
            expressao_tela = "Erro"

    return render_template(
        "index.html", 
        resultado=expressao_tela, 
        erro=erro, 
        metricas=obter_metricas()
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
