from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

bd_config = {
     'host' : 'localhost',
     'user' : 'root',
     'password' : 'escola',
     'database' : 'Cadastro'
}

@app.route('/')
def index():
    return render_template('index.html')

# 1. Mudança: 'POST' deve estar entre aspas
# 2. Se a ideia é APENAS exibir após o cadastro, geralmente usamos GET ou redirecionamento
@app.route('/cliente', methods=['GET', 'POST']) 
def listar_cliente():
    try: 
        # Correção: nomes das variáveis devem ser idênticos (conectar)
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor(dictionary=True) 
        
        # Correção: No SELECT geral, não passamos variáveis como (cpf, nome...)
        query = "SELECT * FROM cliente"
        cursor.execute(query)
        
        dados_clientes = cursor.fetchall()
    
        cursor.close()
        conectar.close()
    
        # O Jinja2 receberá a lista 'dados_clientes' através da variável 'clientes'
        return render_template('tabela.html', clientes=dados_clientes)
    


    except mysql.connector.Error as err:
        return f"Erro ao acessar o banco de dados: {err}"

if __name__ == '__main__':
    app.run(debug=True)
