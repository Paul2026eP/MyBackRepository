# import do flask para criação do servidor
# render_template para criar uma "ponte"com html
# request para capturar os dados digitados
from flask import Flask, render_template, request
import mysql.connector

#ajuda o Flask a localizar os caminhos dos arquivos
app = Flask(__name__)

bd_config = {
   #'chave' : 'valor'
     'host' : 'localhost', #se externo usar a URL do servidor
     'user' : 'root',
     'password' : 'escola',
     'database' : 'Cadastro'
}

#print (type (bd_config)) para listar referencias do DB


#criando uma rota
@app.route('/')
def index():
    return render_template('index.html')


# Rota para processar os dados do formulário (Cadastrar)
@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    # Pegando os dados enviados pelo formulário através dos names do 'input'
    cpf = request.form['cpf']
    primeiro_nome = request.form ['primeiro_nome']
    sobrenome = request.form ['sobrenome']
    idade = request.form ['idade']
     
     
    try:
        #Verificando a conexão com SQL
        conectar = mysql.connector.connect(**bd_config)
        #Variavel que permite escrever SQL
        cursor = conectar.cursor()

        query = "INSERT INTO cliente(CPF, PRIMEIRO_NOME, SOBRENOME, IDADE) VALUES (%s,%s,%s,%s)"
        cursor.execute(query, (cpf, primeiro_nome, sobrenome, idade))

        conectar.commit()
        cursor.close()
        conectar.close()
        return f"<h3>Cliente {primeiro_nome} {sobrenome} com CPF {cpf}, idade {idade} cadastrado com sucesso!<h3> <a href='/'>Voltar</a>"

    except mysql.connector.Error as err:
        return f"Erro ao gravar no banco: {err}"

if __name__ == '__main__':
    app.run(debug=True)