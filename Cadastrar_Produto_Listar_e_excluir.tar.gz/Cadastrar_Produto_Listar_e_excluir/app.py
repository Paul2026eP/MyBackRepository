from flask import Flask, render_template, redirect, url_for, request
import mysql.connector

app = Flask(__name__)

bd_config = {
    'host':'localhost',
    'user':'root',
    'password':'escola',
    'database':'cadastro'
}

# Rota principal: Lista os produtos cadastrados
@app.route('/')
def index():
    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor(dictionary=True)

        # Seleciona todos os campos da tabela de produtos
        cursor.execute("SELECT ID_produto, nome_produto, preco_venda, qt_estoque, status_ativo, data_validade FROM cadastro_de_produtos")
        lista_produtos = cursor.fetchall()

        cursor.close()
        conectar.close()
        # Passa a lista como 'produtos' para o HTML
        return render_template('index.html', produtos=lista_produtos)
    
    except mysql.connector.Error as err:
        return f"Erro ao carregar a tabela: {err}"

# Rota para processar o formulário de produtos
@app.route('/cadastrar_produto', methods=['POST'])
def cadastrar_produto():
    # Captura os dados do formulário (usando os names definidos no HTML)
    nome = request.form['nome_produto']
    preco = request.form['preco_venda']
    estoque = request.form['qt_estoque']
    validade = request.form['data_validade']
    status = request.form['status_ativo']

    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor()

        # Query atualizada para a tabela de produtos
        query = """INSERT INTO cadastro_de_produtos 
                   (nome_produto, preco_venda, qt_estoque, data_validade, status_ativo) 
                   VALUES (%s, %s, %s, %s, %s)"""
        
        cursor.execute(query, (nome, preco, estoque, validade, status))

        conectar.commit()
        cursor.close()
        conectar.close()

        return f"<h3>Produto '{nome}' salvo com sucesso!</h3> <a href='/'>Voltar</a>"
    
    except mysql.connector.Error as err:
        return f"Erro ao gravar no banco: {err}"

# Rota para exclusão baseada no ID do produto
@app.route('/excluir/<int:id_produto>')  # Use minúsculo aqui
def excluir(id_produto):                 # E aqui também
    # ... sua lógica de exclusão usando id_produto ...


    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor()

        cursor.execute("DELETE FROM cadastro_de_produtos WHERE ID_produto = %s", [id_produto])

        conectar.commit()
        cursor.close()
        conectar.close()

        return redirect(url_for('index'))
    except mysql.connector.Error as err:
        return f"Erro ao excluir: {err}"
        
if __name__ == '__main__':
    app.run(debug=True)
