from flask import Flask, render_template, redirect, url_for, request
import mysql.connector

app = Flask(__name__)

# Configuração do Banco de Dados
bd_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'escola',  # Coloque sua senha aqui
    'database': 'cadastro'
}

# ROTA 1: Listar Clientes (Página da Tabela)
@app.route('/')
def index():
    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor(dictionary=True) # dictionary=True facilita o uso no HTML
        cursor.execute("SELECT CPF, PRIMEIRO_NOME, SOBRENOME, IDADE FROM cliente")
        lista_clientes = cursor.fetchall()
        cursor.close()
        conectar.close()
        return render_template('index.html', clientes=lista_clientes)
    except mysql.connector.Error as err:
        return f"Erro ao carregar a tabela: {err}"

# ROTA 2: Cadastrar Cliente
@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    cpf = request.form['cpf']
    primeiro_nome = request.form['primeiro_nome']
    sobrenome = request.form['sobrenome']
    idade = request.form['idade']

    try:
        conectar = mysql.connector.connect(**bd_config)
        cursor = conectar.cursor()
        query = "INSERT INTO cliente (CPF, PRIMEIRO_NOME, SOBRENOME, IDADE) VALUES (%s, %s, %s, %s)"
        cursor.execute(query, (cpf, primeiro_nome, sobrenome, idade))
        conectar.commit()
        cursor.close()
        conectar.close()
        return redirect(url_for('index')) # Redireciona para a lista após salvar
    except mysql.connector.Error as err:
        return f"Erro ao gravar no banco: {err}"



if __name__ == '__main__':
    app.run(debug=True)
