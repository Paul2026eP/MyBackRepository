
x = int(input("digite um valor: "))
contador = 0

if (x > 0):
    print("Olá Mundo")
elif (x < 0):
    print ("Tchau mundo")
else:
    while (contador < 3): #Em for sintaxe= for i in range(3):
        print("Olá Mundo")
        print ("Tchau mundo")
        contador = contador + 1 