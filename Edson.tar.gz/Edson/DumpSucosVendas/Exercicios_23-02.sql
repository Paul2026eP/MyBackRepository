#Problema 1
SELECT nome, de_ferias, bairro FROM tabela_de_vendedores WHERE nome='Cláudia Morais'  AND de_ferias=1;
# A Claudia de ferias, segunda a tabela.

#Problema 2
SELECT nome, de_ferias FROM tabela_de_vendedores WHERE DE_FERIAS=1 AND PERCENTUAL_COMISSAO>0.10;
#A pessoa que está de ferias e tem comissão maior maior 0.10  é a Roberta Martins.

#Problema 3
SELECT MATRICULA, DATA_VENDA,CPF FROM notas_fiscais WHERE MATRICULA=00237 AND DATA_VENDA='2015-01-12';
# O CPF não pode ser a PK; porque existe varias NF em CPF's diferentes na mesma matricula.

#Problema 4
SELECT CODIGO_DO_PRODUTO, QUANTIDADE, PRECO FROM itens_notas_fiscais WHERE QUANTIDADE >= 99 AND PRECO = (SELECT MAX(PRECO) FROM itens_notas_fiscais);
# Os codigo dos produtos de maior valor é 1022450.

#Problema 5
SELECT 